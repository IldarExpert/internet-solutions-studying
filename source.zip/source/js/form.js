/*
$(document).ready(function () {

  let email = $('.footer-top__input'),
  sendButton = $('.footer-top__button');

  if (email == '') {
    email.addClass('error');
  } else {
    email.removeClass('error');
  }
});
*/

$(document).ready(function () {
  $('.slider').slick({
    arrows: false,
    dots: true,
    autoplay: false,
    autoplaySpeed: 2000
  });
});
